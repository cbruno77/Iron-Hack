// Set a variable
let y = 7;
let x = 7;

// Use the prefix increment operation
let postfix = y++;
let prefix = ++x;

console.log(postfix);
console.log(prefix);