let exp = 10 ** 5;
let exp2 = Math.pow(10, 5);

console.log(exp);
console.log(exp2);
