
let n = 0;
let x = 0;
markLoop:
while ( n < 10 ) {
  n++;
  console.log("n: " + n);
  x += n;
  console.log("x: " + x);
}